int waitsem_register(const char *zOrigVfsName, int makeDefault);
int waitsem_unregister(void);
