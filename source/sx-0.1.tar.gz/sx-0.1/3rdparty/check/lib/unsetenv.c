#include "libcompat.h"

int
unsetenv (const char *name CK_ATTRIBUTE_UNUSED)
{
  assert (0);
  return 0;
}
