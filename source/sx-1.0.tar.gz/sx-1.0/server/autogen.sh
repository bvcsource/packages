autoreconf -v --install
rm -rf autom4te.cache
